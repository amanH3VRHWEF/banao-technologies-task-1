# Mini Hospital Management System (HMS)
1. Install PostgreSQL and create a DB named 'hms_db'.
2. Run 'pip install -r requirements.txt'.
3. Run 'python manage.py migrate'.
4. In 'email_service' folder, run 'npm install' and 'sls offline'.
5. Run 'python manage.py runserver'.